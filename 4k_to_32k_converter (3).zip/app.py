
from flask import Flask, render_template, request, send_from_directory
import os
import uuid
from PIL import Image

app = Flask(__name__)

UPLOAD_FOLDER = 'uploads'
OUTPUT_FOLDER = 'outputs'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(OUTPUT_FOLDER, exist_ok=True)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/convert', methods=['POST'])
def convert():
    if 'file' not in request.files:
        return 'No file uploaded', 400

    file = request.files['file']
    resolution = request.form.get('resolution')
    filename = str(uuid.uuid4()) + os.path.splitext(file.filename)[1]
    filepath = os.path.join(UPLOAD_FOLDER, filename)
    file.save(filepath)

    img = Image.open(filepath).convert('RGB')

    new_size = {
        '8k': (7680, 4320),
        '16k': (15360, 8640),
        '32k': (30720, 17280)
    }.get(resolution, (7680, 4320))

    img = img.resize(new_size)
    output_path = os.path.join(OUTPUT_FOLDER, 'upscaled_' + filename)
    img.save(output_path)

    return send_from_directory(OUTPUT_FOLDER, 'upscaled_' + filename, as_attachment=True)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)))
